"""revseg package: Revenue segmentation from SEC 10-K filings."""

